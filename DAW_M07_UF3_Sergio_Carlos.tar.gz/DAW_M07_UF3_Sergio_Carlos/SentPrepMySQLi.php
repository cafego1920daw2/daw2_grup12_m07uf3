<?php
	$dbhost='localhost';
	$dbusername='adcli';
	$dbuserpassword='daw2017';
	$baseDades='bdcli';
	$taula='tlcli';
	try{
		//Connexió
		$connbd = new mysqli($dbhost,$dbusername,$dbuserpassword,$baseDades);
		if ($connbd->connect_errno){
			echo "Problema de connexió a la BD<br><br>";
		}	
		else echo "Connexió a la BD amb èxit<br><br>";
		//Preparació
		$sentencia = $connbd -> prepare("insert into $taula(codi,nom,cognoms,adressa,ciutat,codpost,email) values (?,?,?,?,?,?,?)");
		if (!$sentencia){
			echo "Error de preparació: (" . $connbd->errno . ") " . $connbd->error;
		} 
		//Vinculació. No és obligatori que el nom de la variable sigui igual nom del camp.
		// i --> integer, s --> string, d --> double
		$sentencia->bind_param("issssis", $codi, $nom, $cognom, $adressa, $ciutat, $codpost, $email);
		if (!$sentencia) {
			echo "Error de vinculació: (" . $sentencia->errno . ") " . $sentencia->error;
		}
		//Assignació del valor a cada paràmetre i enviament al servidor amb ordre d'execució
		$codi=8;
		$nom="Hèctor";
		$cognom="Gómez González";
		$adressa="C/Romani, 56, 6è-3a";
		$ciutat="clotcity";
		$codpost="3145";
		$email="hgg@daw2.net";
		if (!$sentencia->execute()) {
			echo "Error d'execució: (" . $sentencia->errno . ") " . $sentencia->error;
		}
		//Assignació del valor a cada paràmetre i enviament al servidor amb ordre d'execució
		$codi=9;
		$nom="Carles";
		$cognom="Tamariu Tona";
		$adressa="C/Llorer, 145, Àtic 3a";
		$ciutat="ciutatfje";
		$codpost="1245";
		$email="ctt@fjesencs.edu";
		if (!$sentencia->execute()) {
			echo "Error d'execució: (" . $sentencia->errno . ") " . $sentencia->error;
		}
		//Missatge
		echo "Les noves dades s'han introduït a la base de dades<br><br>";
		//Consulta a la base de dades amb sentències preparada
		echo "CONSULTA DE TOTA LA TAULA $taula DE LA BASE DE DADES $baseDades<br>";
		$sentencia = $connbd -> prepare("select * from $taula");
		$sentencia->execute();
		$resultat=$sentencia->get_result();
		echo "<table border=1>\n";
		while ($fila = $resultat->fetch_assoc()) {
			echo "\t<tr>\n";
			foreach ($fila as $valor_columna) {
				echo "\t\t<td> $valor_columna </td>\n";
			}
			echo "\t</tr>\n";
		}
		echo "</table>\n";
		echo "<br>";
		echo "CONSULTA DE TOTS ELS CLIENT QUE VIUEN A clotcity<br>";
		$ciutat="clotcity";
		$sentencia = $connbd -> prepare("select * from $taula where ciutat = ?"); //Prepara
		$sentencia->bind_param("s", $ciutat); //Vincula
		$sentencia->execute(); //Executa
		$resultat=$sentencia->get_result(); //Desa el resultat dins d'una variable
		echo "<table border=1>\n";
		while ($fila = $resultat->fetch_assoc()) {
			echo "\t<tr>\n";
			foreach ($fila as $valor_columna) {
				echo "\t\t<td> $valor_columna </td>\n";
			}
			echo "\t</tr>\n";
		}
		echo "</table>\n";					
		//Tancant connexió
		$connbd->close();		
	} 
	catch(PDOException $e){
		print "Error!!! ".$e->getMessage()."<br>";
		die();
	}
?>
