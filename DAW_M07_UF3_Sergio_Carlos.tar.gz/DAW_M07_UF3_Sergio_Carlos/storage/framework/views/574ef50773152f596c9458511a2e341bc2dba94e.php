<!DOCTYPE >
<html>
<head>
<title>Añadir Canal</title>
</head>
<body>
<?php if(\Session::has('Exit')): ?>
        <div class="alert alert-success">
          <p><?php echo e(\Session::get('Exit')); ?></p>
        </div>
      <?php endif; ?>
<form action="<?php echo e(url('canals')); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<br>
<b>Introduce Un canal de Television<br><br>
</b>
Nombre
<input type="text" name="nomCanal">
<br>
</b>
id
<input type="number" name="idcanal">
<br><br>
<input value="Enviar datos" type="submit">
</form>
</body>
</html>

<?php /**PATH /var/www/html/DAW_M07_UF3_Sergio_Carlos/resources/views/canals/AñadirCanal.blade.php ENDPATH**/ ?>