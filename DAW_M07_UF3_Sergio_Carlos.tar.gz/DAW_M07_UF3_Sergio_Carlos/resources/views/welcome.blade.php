<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php
        session_start();
        if (isset($_SESSION['nomm'])){
            echo $_SESSION['nomm'];
        }
        ?>
        <title>Digital++</title>
        </head>
        <h1>Digital++</h1>
          <table>
        <tr>
            <th>Canal</th>
            <th>Programa</th>
            <th>Graella</th>
        </tr>
        <tr>
            <td><a href="canals/create">Agregar</a></td>
            <td><a href="programas/create">Agregar</a></td>
            <td><a href="graella/create">Agregar</td>
        </tr>
        <tr>
        
            <td><a href="http://localhost/DAW_M07_UF3_Sergio_Carlos/resources/views/canals/modificarcanal.php">Modificar</a></td>
            <td><a href="http://localhost/DAW_M07_UF3_Sergio_Carlos/resources/views/programas/modificarprograma.php">Modificar</a></td>
            <td><a href="http://localhost/DAW_M07_UF3_Sergio_Carlos/resources/views/graella/graella.php">Modificar</a></td>
        </tr>
        <tr>
        
        
            <td><a href="http://localhost/DAW_M07_UF3_Sergio_Carlos/resources/views/canals/BorrarCanal.php"> Borrar</a></td>
            <td><a href="http://localhost/DAW_M07_UF3_Sergio_Carlos/resources/views/programas/Borrarprograma.php">Borrar</a><</td>
            <td><a href="http://localhost/DAW_M07_UF3_Sergio_Carlos/resources/views/graella/Borrargraella.php">Borrar</a></td>
        </tr>
        </table>
        
        <h1>Programas</h1>
        <?php
        $dbhost='localhost';
        $dbusername='m07';
        $dbuserpassword='daw2';
        $baseDades='Digital';
   
$mysqli = new mysqli($dbhost,$dbusername,$dbuserpassword,$baseDades);
if ($mysqli->connect_errno){
    echo "Problema de connexió a la BD";
}
else {
    echo "<b>Connexió a la BD  $baseDades realitzada amb èxit</b><br><br>";
}
$consulta = 'SELECT * FROM programas';
$resultat = $mysqli->query($consulta) or die('Consulta fallida: ' . $mysqli->errno . $mysqli->error);
echo "<b>Entrades de la base de dades: </b>";
echo "<table>\n";
echo "\t<tr>\n";
 echo "\t\t<th>idPrograma</th>\n";
 echo "\t\t<th>nom</th>\n";
 echo "\t\t<th>tipus </th>\n";
 echo "\t\t<th>clasificacio</th>\n";
 echo "\t\t<th>idCanalpro</th>\n";
echo "\t</tr>\n";
while ($fila = $resultat->fetch_assoc()) {
    echo "\t<tr>\n";
    foreach ($fila as $valor_columna) {
        echo "\t\t<td> $valor_columna </td>\n";
    }
    echo "\t</tr>\n";
}
echo "</table>\n";
echo "<br><b>Total registres:</b> " .$resultat->num_rows;
$mysqli->close();


        ?>

<h1>Canals</h1>
        <?php
        $dbhost='localhost';
        $dbusername='m07';
        $dbuserpassword='daw2';
        $baseDades='Digital';
   
$mysqli = new mysqli($dbhost,$dbusername,$dbuserpassword,$baseDades);
if ($mysqli->connect_errno){
    echo "Problema de connexió a la BD";
}
else {
    echo "<b>Connexió a la BD  $baseDades realitzada amb èxit</b><br><br>";
}
$consulta = 'SELECT * FROM canals';
$resultat = $mysqli->query($consulta) or die('Consulta fallida: ' . $mysqli->errno . $mysqli->error);
echo "<b>Entrades de la base de dades: </b>";
echo "<table>\n";
echo "\t<tr>\n";
 echo "\t\t<th>idCanal</th>\n";
 echo "\t\t<th>nomCanal</th>\n";
echo "\t</tr>\n";
while ($fila = $resultat->fetch_assoc()) {
    echo "\t<tr>\n";
    foreach ($fila as $valor_columna) {
        echo "\t\t<td> $valor_columna </td>\n";
    }
    echo "\t</tr>\n";
}
echo "</table>\n";
echo "<br><b>Total registres:</b> " .$resultat->num_rows;
$mysqli->close();


        ?>
         <h1>graella</h1>
        <?php
        $dbhost='localhost';
        $dbusername='m07';
        $dbuserpassword='daw2';
        $baseDades='Digital';
   
$mysqli = new mysqli($dbhost,$dbusername,$dbuserpassword,$baseDades);
if ($mysqli->connect_errno){
    echo "Problema de connexió a la BD";
}
else {
    echo "<b>Connexió a la BD  $baseDades realitzada amb èxit</b><br><br>";
}
$consulta = 'SELECT * FROM graella';
$resultat = $mysqli->query($consulta) or die('Consulta fallida: ' . $mysqli->errno . $mysqli->error);
echo "<b>Entrades de la base de dades: </b>";
echo "<table>\n";
echo "\t<tr>\n";
 echo "\t\t<th>idgraellaprograma </th>\n";
 echo "\t\t<th>hora</th>\n";
 echo "\t\t<th>dia </th>\n";
 echo "\t\t<th>nom programa</th>\n";
 echo "\t\t<th>nom canal</th>\n";
echo "\t</tr>\n";
while ($fila = $resultat->fetch_assoc()) {
    echo "\t<tr>\n";
    foreach ($fila as $valor_columna) {
        echo "\t\t<td> $valor_columna </td>\n";
    }
    echo "\t</tr>\n";
}
echo "</table>\n";
echo "<br><b>Total registres:</b> " .$resultat->num_rows;
$mysqli->close();
            
        

        ?>
    </body>
</html>
