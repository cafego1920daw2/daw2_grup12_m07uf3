<?php
$dbhost='localhost';
$dbusername='m07';
$dbuserpassword='daw2';
$baseDades='Digital';

$mysqli = new mysqli($dbhost,$dbusername,$dbuserpassword,$baseDades);
if ($mysqli->connect_errno){
echo "Problema de connexió a la BD";
}
else {
echo "<b>Connexió a la BD  $baseDades realitzada amb èxit</b><br><br>";
}
$consulta = 'SELECT * FROM programas';
$resultat = $mysqli->query($consulta) or die('Consulta fallida: ' . $mysqli->errno . $mysqli->error);
echo "<b>Entrades de la base de dades: </b>";
echo "<table>\n";
echo "\t<tr>\n";
echo "\t\t<th>idPrograma</th>\n";
echo "\t\t<th>nom</th>\n";
echo "\t\t<th>tipus </th>\n";
echo "\t\t<th>clasificacio</th>\n";
echo "\t\t<th>idCanalpro</th>\n";
echo "\t</tr>\n";
while ($fila = $resultat->fetch_assoc()) {
echo "\t<tr>\n";
foreach ($fila as $valor_columna) {
echo "\t\t<td> $valor_columna </td>\n";
}
echo "\t</tr>\n";
}
echo "</table>\n";
echo "<br><b>Total registres:</b> " .$resultat->num_rows;
$mysqli->close();




?>

<!DOCTYPE >
<html>
<head>
<title>Añadir Canal</title>
</head>
<body>

<form action="modificarprograma.php" method="POST">
Nombre
<input type="text" name="nomPrograma">
<br>
</b>
id
<input type="number" name="idPrograma">
<br>
</b>
Descripcion
<input type="text" name="DesPrograma">
<br>
</b>
tipus
<input type="text" name="tipusPrograma">
<br>
</b>
clasificacio
<input type="number" name="clasificacioPrograma">
<br>
</b>
idCanalpro
<?php
$dbhost='localhost';
$dbusername='m07';
$dbuserpassword='daw2';
$baseDades='Digital';
$taula='canals';
$connbd = new mysqli($dbhost,$dbusername,$dbuserpassword,$baseDades);
	if ($connbd->connect_errno){
		echo "Problema de connexió a la BD<br><br>";
	}
$consulta = "select idcanal from $taula;";

if(!$connbd -> multi_query($consulta)) echo "Error de sentència múltiple";
	else{
		do{
			$resultat=$connbd->store_result();//s'agafa el resultat d'una consulta
      ?>
<select name="idCanalpro">
      <option  value="0">Seleccione</option>
      <?php
			while ($fila = $resultat->fetch_assoc()) {
			echo '<option value="'.$fila[idcanal].'">'.$fila[idcanal].'</option>';
				
				
			}
	?>
</select>
  <?php				 
		}while($connbd->more_results() && $connbd->next_result()); //mentre no finalitzin les consultes
	}
	//Tancant connexió
	$connbd->close();		
?>

<br><br>
<button type="submit" name="submit" class="btn btn-primary">Afegir Usuari</button>

</form>
<?php
if(isset($_POST['submit'])){
    $dbhost='localhost';
    $dbusername='m07';
    $dbuserpassword='daw2';
    $baseDades='Digital';
    $taula='canals';
    $var1=$_POST['idPrograma'];
$var2=$_POST['nomPrograma'];
$var3=$_POST['DesPrograma'];
$var4=$_POST['tipusPrograma'];
$var5=$_POST['clasificacioPrograma'];
$var6=(int) $_POST['idCanalpro'];
	try{
		//Connexió
		$connbd = new PDO("mysql:host=$dbhost;dbname=$baseDades",$dbusername,$dbuserpassword);
		echo "Conenxió amb  $users $id la base de dades $baseDades realitzada amb èxit<br><br>";
        //Preparació
        
		$entrada = "UPDATE programas SET nomPrograma='$var2',DesPrograma='$var3',tipusPrograma='$var4',clasificacioPrograma'=$var5 WHERE idCanalpro = $var6";
		$connbd->exec($entrada);
		$error = $connbd->errorInfo();		
		if ($error[0] != 0){
            echo "Se ha actualizado con exito<br>";		
             ?>
			<META HTTP-EQUIV="REFRESH" CONTENT="2;URL=http://www.projm07.net/">	
			<?php		
		}
		else{
            echo "Uff hha sucedido un error<br>";
            ?>
			<META HTTP-EQUIV="REFRESH" CONTENT="2;URL=http://www.projm07.net/">	
			<?php	
		}
		$connbd=null;//Tancant connexió
}
 catch(PDOException $e){
    print "Error!!! ".$e->getMessage()."<br>";
    die();
}	
}
?>
</body>
</html>
