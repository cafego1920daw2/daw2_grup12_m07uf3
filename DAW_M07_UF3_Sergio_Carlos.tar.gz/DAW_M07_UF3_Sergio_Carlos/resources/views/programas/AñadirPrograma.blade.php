<META HTTP-EQUIV="REFRESH" CONTENT="2;URL=http://localhost/DAW_M07_UF3_Sergio_Carlos/resources/views/programas/A%c3%b1adirPrograma.php">
<p>Redireccionando....</p>