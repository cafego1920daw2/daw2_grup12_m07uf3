<!DOCTYPE >
<html>
<head>
<title>Añadir Programa</title>
</head>
<body>
<form action="AñadirPrograma.php"	 method=post  class="mx-auto	" style="width: 500px; margin-top: 10%;">
<br>
<b>Introduce Un canal de Programas<br><br>
</b>
Nombre
<input type="text" name="nomPrograma">
<br>
</b>
id
<input type="number" name="idPrograma">
<br>
</b>
Descripcion
<input type="text" name="DesPrograma">
<br>
</b>
tipus
<input type="text" name="tipusPrograma">
<br>
</b>
clasificacio
<input type="number" name="clasificacioPrograma">
<br>
</b>
idCanalpro
<?php
$dbhost='localhost';
$dbusername='m07';
$dbuserpassword='daw2';
$baseDades='Digital';
$taula='canals';
$connbd = new mysqli($dbhost,$dbusername,$dbuserpassword,$baseDades);
	if ($connbd->connect_errno){
		echo "Problema de connexió a la BD<br><br>";
	}
$consulta = "select idcanal from $taula;";

if(!$connbd -> multi_query($consulta)) echo "Error de sentència múltiple";
	else{
		do{
			$resultat=$connbd->store_result();//s'agafa el resultat d'una consulta
      ?>
<select name="idCanalpro">
      <option  value="0">Seleccione</option>
      <?php
			while ($fila = $resultat->fetch_assoc()) {
			echo '<option value="'.$fila[idcanal].'">'.$fila[idcanal].'</option>';
				
				
			}
	?>
</select>
  <?php				 
		}while($connbd->more_results() && $connbd->next_result()); //mentre no finalitzin les consultes
	}
	//Tancant connexió
	$connbd->close();		
?>

<br><br>
<button type="submit" name="submit" class="btn btn-primary">Afegir Usuari</button>
</form>
<?php
if(isset($_POST['submit'])){

	$dbhost='localhost';
$dbusername='m07';
$dbuserpassword='daw2';
$baseDades='Digital';
$taula='programas';
$var1=$_POST['idPrograma'];
$var2=$_POST['nomPrograma'];
$var3=$_POST['DesPrograma'];
$var4=$_POST['tipusPrograma'];
$var5=$_POST['clasificacioPrograma'];
$var6=(int) $_POST['idCanalpro'];
	try{
		$connexio = new PDO("mysql:host=$dbhost;dbname=$baseDades",$dbusername,$dbuserpassword);
		echo "$var1,'$var2','$var3','$var4',$var5,dd $var6<br><br><br> ";
		$entrada = "INSERT INTO ".$taula." VALUES($var1,'$var2','$var3','$var4',$var5,$var6)";
		$connexio->exec($entrada);
		$error = $connexio->errorInfo();		
		if ($error[0] != 0){
			echo "Error introduint el nou registre<br>";
			?>
			<META HTTP-EQUIV="REFRESH" CONTENT="2;URL=http://www.projm07.net/">	
			<?php		
		}
		else{
			echo "El nou registre s'ha introduït amb èxit<br>";
			?>
			<META HTTP-EQUIV="REFRESH" CONTENT="2;URL=http://www.projm07.net/">	
			<?php	
		}
		$connexio=null;//Tancant connexió
	} 
	catch(PDOException $e){
		print "Error!!! ".$e->getMessage()."<br>";
		die();
	}



}
?>
</body>
</html>