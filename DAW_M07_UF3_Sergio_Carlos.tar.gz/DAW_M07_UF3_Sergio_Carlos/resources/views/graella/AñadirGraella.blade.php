<META HTTP-EQUIV="REFRESH" CONTENT="2;URL=http://localhost/DAW_M07_UF3_Sergio_Carlos/resources/views/graella/graella.php">
<p>Redireccionando....</p>