<!DOCTYPE >
<html>
<head>
<title>Añadir Graella</title>
</head>
<body>
<form action="graella.php"	 method=post  class="mx-auto	" style="width: 500px; margin-top: 10%;">
<br>
<b>Introduce Una graella de Television<br><br>
</b>
Dia
<input type="date" name="Dia">
<br>
</b>
Hora
<input type="text" name="Hora">
<br>
</b>

id
<input type="number" name="idgraella">
<br>
idpro
<?php
$dbhost='localhost';
$dbusername='m07';
$dbuserpassword='daw2';
$baseDades='Digital';
$taula='programas';
$connbd = new mysqli($dbhost,$dbusername,$dbuserpassword,$baseDades);
	if ($connbd->connect_errno){
		echo "Problema de connexió a la BD<br><br>";
	}
$consulta = "select nom from $taula;";

if(!$connbd -> multi_query($consulta)) echo "Error de sentència múltiple";
	else{
		do{
			$resultat=$connbd->store_result();//s'agafa el resultat d'una consulta
      ?>
<select name="idCanalpro">
      <option  value="0">Seleccione</option>
      <?php
			while ($fila = $resultat->fetch_assoc()) {
			echo '<option value="'.$fila[nom].'">'.$fila[nom].'</option>';
				
			}
	?>
</select>
  <?php				 
		}while($connbd->more_results() && $connbd->next_result()); //mentre no finalitzin les consultes
	}
	//Tancant connexió
	$connbd->close();		
?>
<br>
idCanal
<?php
$dbhost='localhost';
$dbusername='m07';
$dbuserpassword='daw2';
$baseDades='Digital';
$taula='canals';
$connbd = new mysqli($dbhost,$dbusername,$dbuserpassword,$baseDades);
	if ($connbd->connect_errno){
		echo "Problema de connexió a la BD<br><br>";
	}
$consulta = "select nomCanal from $taula;";

if(!$connbd -> multi_query($consulta)) echo "Error de sentència múltiple";
	else{
		do{
			$resultat=$connbd->store_result();//s'agafa el resultat d'una consulta
      ?>
<select name="idCanal">
      <option value="0">Seleccione</option>
	  <?php
			while ($fila = $resultat->fetch_assoc()) {
			echo '<option value="'.$fila[nomCanal].'">'.$fila[nomCanal].'</option>';
			}
	?>
</select>
  <?php				 
		}while($connbd->more_results() && $connbd->next_result()); //mentre no finalitzin les consultes
	}
	//Tancant connexió
	$connbd->close();		
?>
<br><br>
<button type="submit" name="submit" class="btn btn-primary">Afegir Usuari</button>
</form>
<?php
if(isset($_POST['submit'])){

	$dbhost='localhost';
$dbusername='m07';
$dbuserpassword='daw2';
$baseDades='Digital';
$taula='graella';
$var1=(int) $_POST['idgraella'];
$var2=(string) $_POST['Dia'];
$var3=(string) $_POST['Hora'];
$var4=(int) $_POST['idCanalpro'];
$var5=(int) $_POST['idCanal'];

	try{
		$connexio = new PDO("mysql:host=$dbhost;dbname=$baseDades",$dbusername,$dbuserpassword);
		echo "$var1,'$var2','$var3','$var4',$var5,dd $var6<br><br><br> ";
		$entrada = "INSERT INTO ".$taula." VALUES($var1,$var2,$var3,'$var4','$var5')";
		$connexio->exec($entrada);
		$error = $connexio->errorInfo();		
		if ($error[0] != 0){
			echo "Error introduint el nou registre<br>";
			?>
			<META HTTP-EQUIV="REFRESH" CONTENT="2;URL=http://www.projm07.net/">	
			<?php		
		}
		else{
			echo "El nou registre s'ha introduït amb èxit<br>";
			?>
			<META HTTP-EQUIV="REFRESH" CONTENT="2;URL=http://www.projm07.net/">	
			<?php	
		}
		$connexio=null;//Tancant connexió
	} 
	catch(PDOException $e){
		print "Error!!! ".$e->getMessage()."<br>";
		die();
	}



}
?>
</body>
</html>
