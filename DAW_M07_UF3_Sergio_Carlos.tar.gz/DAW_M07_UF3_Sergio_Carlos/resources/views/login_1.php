<?php
session_start();
    $dbhost='localhost';
$dbusername='m07';
$dbuserpassword='daw2';
$baseDades='Digital';
$taula='users';
    $username=$_GET['nomm'];
$password=$_GET['pass'];
try{
    $pdo = new PDO("mysql:host=$dbhost;dbname=$baseDades",$dbusername,$dbuserpassword);
    echo "<b>Connexió a la BD  $baseDades realitzada amb èxit</b><br><br>";
    $consulta = "SELECT * FROM $taula";
    $resultat = $pdo->query($consulta);
    echo "<b>Entrades de la base de dades $baseDades: </b><br><br>";
   
    $counter = $resultat->rowCount();
    echo "numero de rows $counter";
    if ($counter==1){
		$_SESSION['nom']=$username; // Iniciando la sesion
        echo $_SESSION['nom'];
        ?>
			<META HTTP-EQUIV="REFRESH" CONTENT="2;URL=http://www.projm07.net/">	
			<?php	
	} else {
       echo "El correo electrónico o la contraseña es inválida.";	
}
    $pdo=null;//Tancant connexió
} catch(PDOException $e){
    print "Error!!! ".$e->getMessage()."<br>";
    die();
}
?>