<?php
	$dbhost='localhost';
	$dbusername='adcli';
	$dbuserpassword='daw2017';
	$baseDades='bdcli';
	$taula='tlcli';
	//Connexió
	$connbd = new mysqli($dbhost,$dbusername,$dbuserpassword,$baseDades);
	if ($connbd->connect_errno){
		echo "Problema de connexió a la BD<br><br>";
	}
	echo "Inici de transacció<br>";
	$connbd->autocommit(FALSE);
	$entrada1 = "INSERT INTO $taula VALUES(10,'jordi','bonaventura blay', 'C/Pi,45,2-3', 'dawcity',2017,'jbb@dawsencs.net')";
	$entrada2 = "INSERT INTO $taula VALUES(11,'david','niubó navals', 'C/Alfabrega, 145, 1-3', 'ciutatfje', 12017,'dnn@clotencs.net')";
	$entrada3 = "INSERT INTO $taula VALUES(12,'linus','altamira aleix', 'C/Alfabrega, 145, 1-3', 'ciutatfje', 12017,'dnn@clotencs.net')";
	$connbd->query($entrada1);
	$connbd->query($entrada2);
	$connbd->query($entrada3);
	if(!$connbd->commit()){
		echo "Error de transacció<br>";		
	}	
	echo "Transacció finalitzada<br>";
	//Tancant connexió
	$connbd->close();			
?>
