<?php
	$dbhost='localhost';
	$dbusername='adcli';
	$dbuserpassword='daw2017';
	$baseDades='bdcli';
	$taula='tlcli';
	try{
		//Connexió
		$connbd = new PDO("mysql:host=$dbhost;dbname=$baseDades",$dbusername,$dbuserpassword);
		echo "Conenxió amb la base de dades $baseDades realitzada amb èxit<br><br>";
		//Preparació
		$sentencia = $connbd -> prepare("insert into $taula(codi,nom,cognoms,adressa,ciutat,codpost,email) values (?,?,?,?,?,?,?)");
		if (!$sentencia){
			echo "Error de preparació: (" . $connbd->errno . ") " . $connbd->error;
		} 
		//Vinculació. No és obligatori que el nom de la variable sigui igual nom del camp.
		$sentencia->bindParam(1, $codi);
		$sentencia->bindParam(2, $nom);
		$sentencia->bindParam(3, $cognom);
		$sentencia->bindParam(4, $adressa);
		$sentencia->bindParam(5, $ciutat);
		$sentencia->bindParam(6, $codpost);
		$sentencia->bindParam(7, $email);
		//Assignació del valor a cada paràmetre i enviament al servidor amb ordre d'execució
		$codi=6;
		$nom="Francesc";
		$cognom="Siurana Sants";
		$adressa="C/Farigola, 34, 1r-3a";
		$ciutat="clotcity";
		$codpost="3045";
		$email="fss@daw2.net";
		if (!$sentencia->execute()) {
			echo "Error d'execució: (" . $sentencia->errno . ") " . $sentencia->error;
		}
		//Assignació del valor a cada paràmetre i enviament al servidor amb ordre d'execució
		$codi=7;
		$nom="Ramon";
		$cognom="Llopis Lopéz";
		$adressa="C/Alfabrega, 45, 2n-4a";
		$ciutat="clotcity";
		$codpost="4245";
		$email="rll@clotencs.edu";		
		if (!$sentencia->execute()) {
			echo "Error d'execució: (" . $sentencia->errno . ") " . $sentencia->error;
		}
		//Missatge
		echo "Les noves dades s'han introduït a la base de dades<br><br>";
		//Consulta a la base de dades amb sentències preparada
		echo "CONSULTA DE TOTA LA TAULA $taula DE LA BASE DE DADES $baseDades<br>";
		$sentencia = $connbd -> prepare("select * from $taula");
		$sentencia->execute();
		echo "<table border=1>\n";
		while ($fila = $sentencia->fetch(PDO::FETCH_ASSOC)) {
			echo "\t<tr>\n";
			foreach ($fila as $valor_columna) {
				echo "\t\t<td> $valor_columna </td>\n";
			}
			echo "\t</tr>\n";
		}
		echo "</table>\n";
		echo "<br>";
		echo "CONSULTA DE TOTS ELS CLIENT QUE VIUEN A clotcity<br>";
		$ciutat="clotcity";
		$sentencia = $connbd -> prepare("select * from $taula where ciutat = ?");//Prepara
		$sentencia->execute(array($ciutat));//Vincula i executa		
		echo "<table border=1>\n";
		while ($fila = $sentencia->fetch(PDO::FETCH_ASSOC)) {
			echo "\t<tr>\n";
			foreach ($fila as $valor_columna) {
				echo "\t\t<td> $valor_columna </td>\n";
			}
			echo "\t</tr>\n";
		}
		echo "</table>\n";
		//Tancant connexió
		$connexio=null;
	} 
	catch(PDOException $e){
		print "Error!!! ".$e->getMessage()."<br>";
		die();
	}
?>
