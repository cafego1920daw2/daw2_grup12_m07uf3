<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Canals extends Model {
    protected $fillable = ['idcanal','nomCanal'];
}	
?>