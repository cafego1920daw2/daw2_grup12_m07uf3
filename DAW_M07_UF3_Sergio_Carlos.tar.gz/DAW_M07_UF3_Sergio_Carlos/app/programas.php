<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class programas extends Model {
    protected $fillable = ['idProgrdama','nomPrograma','DesPrograma','tipusPrograma','clasificacioPrograma','idCanalpro'];
}	
?>
