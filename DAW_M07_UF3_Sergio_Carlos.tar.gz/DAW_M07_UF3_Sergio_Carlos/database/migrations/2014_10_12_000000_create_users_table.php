<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('canals', function (Blueprint $table) {
            $table->integer('idCanal')->unique();
            $table->string('nomCanal');
            
            $table->timestamps();
        });

        Schema::create('Programas', function (Blueprint $table) {
            $table->integer('idPrograma')->unique();
            $table->string('descripcion');
            $table->string('tipus');
            $table->integer('clasificacio');
            $table->integer('idCanalpro');
            
            $table->timestamps();
        });

        Schema::create('users', function (Blueprint $table) {
            $table->integer('id');
            $table->string('nameuser')->unique();
            $table->string('password');
            
            $table->timestamps();
        });

        Schema::create('Graella', function (Blueprint $table) {
            $table->integer('idgraellaprograma');
            $table->integer('hora');
            $table->integer('dia');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
        Schema::dropIfExists('Canals');
        Schema::dropIfExists('Graella');
        Schema::dropIfExists('Programas');
    }
}
